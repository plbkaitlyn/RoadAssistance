﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MySql.Data.MySqlClient;
using System.Web.Script.Serialization;
using System.Configuration;
using System.Text.RegularExpressions;

namespace RoadAssistance
{
    public class CustomerDBData
    {
        public void CustomerRegister(Customer newUser)
        {
            string _connectionString = ConfigurationManager.ConnectionStrings["dbconnection"].ToString();
            using (MySqlConnection connection = new MySqlConnection(_connectionString))
            {
                connection.Open();
                try
                {
                    string userQuery = "INSERT INTO user(userType, userName, userpassword) VALUES (@type, @name, @password)";

                    MySqlCommand userCmd = new MySqlCommand(userQuery, connection);
                    userCmd.Parameters.AddWithValue("@name", newUser.Name);
                    userCmd.Parameters.AddWithValue("@type", "customer");
                    userCmd.Parameters.AddWithValue("@password", newUser.Password);
                    userCmd.ExecuteNonQuery();

                    string query = "SELECT userID FROM user WHERE userName = @name";
                    MySqlCommand cmd = new MySqlCommand(query, connection);
                    cmd.Parameters.AddWithValue("@name", newUser.Name);
                    MySqlDataReader dataReader = cmd.ExecuteReader();
                    int userID = 0;
                    if (dataReader.Read())
                    {
                        userID = Convert.ToInt32(dataReader["userID"]);
                    }

                    connection.Close();
                    connection.Open();

                    string customerQuery = "INSERT INTO customer VALUES (@userID, @name, @password, @email)";
                    MySqlCommand customerCmd = new MySqlCommand(customerQuery, connection);
                    customerCmd.Parameters.AddWithValue("@userID", userID);
                    customerCmd.Parameters.AddWithValue("@name", newUser.Name);
                    customerCmd.Parameters.AddWithValue("@password", newUser.Password);
                    customerCmd.Parameters.AddWithValue("@email", newUser.Email);
                    customerCmd.ExecuteNonQuery();
                }
                catch (MySqlException ex)
                {
                    if (ex.Message.Contains("user_ck1"))
                    {

                        throw new System.ApplicationException("Username has already been used. Please try another one!");
                    }
                    else if (ex.Message.Contains("customer_ck2"))
                    {

                        throw new System.ApplicationException("You have already used this email address to register!");
                    }
                    else
                    {
                        throw new System.ApplicationException(ex.Message);
                    }
                }
            }
        }
    }
}