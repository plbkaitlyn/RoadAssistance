﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MySql.Data.MySqlClient;
using System.Web.Script.Serialization;
using System.Configuration;
using System.Text.RegularExpressions;

namespace RoadAssistance
{
    public class ContractorDBData
    {
        string _connectionString = ConfigurationManager.ConnectionStrings["dbconnection"].ToString();

        public ContractorDBData() { }

        public void ContractorRegister(Contractor newUser)
        {
            using (MySqlConnection connection = new MySqlConnection(_connectionString))
            {
                connection.Open();
                try
                {
                    string userQuery = "INSERT INTO user(userType, userName, userpassword) VALUES (@type, @name, @password)";

                    MySqlCommand userCmd = new MySqlCommand(userQuery, connection);
                    userCmd.Parameters.AddWithValue("@name", newUser.Name);
                    userCmd.Parameters.AddWithValue("@type", "contractor");
                    userCmd.Parameters.AddWithValue("@password", newUser.Password);
                    userCmd.ExecuteNonQuery();

                    string query = "SELECT userID FROM user WHERE userName = @name";
                    MySqlCommand cmd = new MySqlCommand(query, connection);
                    cmd.Parameters.AddWithValue("@name", newUser.Name);
                    MySqlDataReader dataReader = cmd.ExecuteReader();
                    int userID = 0;
                    if (dataReader.Read())
                    {
                        userID = Convert.ToInt32(dataReader["userID"]);
                    }

                    connection.Close();
                    connection.Open();

                    string contractorQuery = "INSERT INTO contractor VALUES (@userID, @license, @name, @password, @email)";
                    MySqlCommand contractorCmd = new MySqlCommand(contractorQuery, connection);
                    contractorCmd.Parameters.AddWithValue("@userID", userID);
                    contractorCmd.Parameters.AddWithValue("@license", newUser.License);
                    contractorCmd.Parameters.AddWithValue("@name", newUser.Name);
                    contractorCmd.Parameters.AddWithValue("@password", newUser.Password);
                    contractorCmd.Parameters.AddWithValue("@email", newUser.Email);
                    contractorCmd.ExecuteNonQuery();

                    connection.Close();
                    connection.Open();

                    string accQuery = "INSERT INTO account(accName, accNo, bsb, userID) VALUES (@accName, @accNo, @bsb, @userID)";
                    MySqlCommand accCmd = new MySqlCommand(accQuery, connection);
                    accCmd.Parameters.AddWithValue("@userID", userID);
                    accCmd.Parameters.AddWithValue("@accName", newUser.AccountName);
                    accCmd.Parameters.AddWithValue("@accNo", newUser.AccountNumber);
                    accCmd.Parameters.AddWithValue("@bsb", newUser.BSB);
                    accCmd.ExecuteNonQuery();
                }
                catch (MySqlException ex)
                {
                    if (ex.Message.Contains("user_ck1"))
                    {

                        throw new System.ApplicationException("Username has already been used. Please try another one!");
                    }
                    else if (ex.Message.Contains("contractor_ck3"))
                    {

                        throw new System.ApplicationException("You have already used this email address to register!");
                    }
                    else if (ex.Message.Contains("contractor_ck1"))
                    {
                        throw new System.ApplicationException("You have already used this motor tradeperson certificate number!");
                    }
                    else
                    {
                        throw new System.ApplicationException(ex.Message);
                    }
                }
            }
        }
    }
}