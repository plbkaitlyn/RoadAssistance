DROP TABLE VEHICLE;
DROP TABLE PAYMENT;
DROP TABLE CUSTOMER;
DROP TABLE ACCOUNT;
DROP TABLE CONTRACTOR;
DROP TABLE USER;

CREATE TABLE USER (
	userID			INTEGER				AUTO_INCREMENT,
	userType		VARCHAR(100)		NOT NULL,
	userName		VARCHAR(100)		NOT NULL,
	userPassword	VARCHAR(200)		NOT NULL,
	CONSTRAINT user_pk PRIMARY KEY (userID),
	CONSTRAINT user_ck1 UNIQUE (userName)
);

CREATE TABLE CUSTOMER (
	userID			INTEGER				NOT NULL,
	userName		VARCHAR(50)			NOT NULL,
    userPassword	VARCHAR(200)		NOT NULL,
	email			VARCHAR(200)		NOT NULL,
    CONSTRAINT customer_pk PRIMARY KEY (userID),
	CONSTRAINT customer_ck1 UNIQUE (userName),
	CONSTRAINT customer_ck2 UNIQUE (email)
);

CREATE TABLE CONTRACTOR (
	userID			INTEGER				NOT NULL,
	license			INTEGER				NOT NULL,
	userName		VARCHAR(50)			NOT NULL,
    userPassword	VARCHAR(200)		NOT NULL,
	email			VARCHAR(200)		NOT NULL,
    CONSTRAINT contrator_pk PRIMARY KEY (userID),
	CONSTRAINT contractor_ck1 UNIQUE (license),
	CONSTRAINT contractor_ck2 UNIQUE (userName),
	CONSTRAINT contractor_ck3 UNIQUE (email)
);

CREATE TABLE VEHICLE (
	regNo			VARCHAR(300)				NOT NULL,
	maker			VARCHAR(300)		NOT NULL,
	model			VARCHAR(300)		NOT NULL,
	color			VARCHAR(100)		NOT NULL,
	userID			INTEGER				NOT NULL,
	CONSTRAINT vehicle_pk PRIMARY KEY (regNo),
	CONSTRAINT vehicle_fk FOREIGN KEY (userID) REFERENCES CUSTOMER (userID)
);

CREATE TABLE PAYMENT (
	cardHolder		VARCHAR(300)		NOT NULL,
	cardNo			INTEGER				NOT NULL,
	expiryDate		DATE				NOT NULL,
	cvv				INTEGER				NOT NULL,
	userID			INTEGER				NOT NULL,
	CONSTRAINT payment_pk PRIMARY KEY (cardNo),
	CONSTRAINT payment_fk FOREIGN KEY (userID) REFERENCES CUSTOMER (userID)
);

CREATE TABLE ACCOUNT (
	accID			INTEGER				AUTO_INCREMENT,
	accName			VARCHAR(300)		NOT NULL,
	accNo			INTEGER				NOT NULL,
	bsb				INTEGER				NOT NULL,
	userID			INTEGER				NOT NULL,
	CONSTRAINT account_pk	PRIMARY KEY (accID),
	CONSTRAINT account_fk	FOREIGN KEY (userID) REFERENCES CONTRACTOR (userID)
);
/*Register:
Sign up as Customer: get the field id => insert into User table
with userType="customer"
=>also need to insert into customer table
Sign up as Contractor: similar, userType="contractor"
=>also need to insert into contractor table
*/