﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RoadAssistance
{
    public class Customer : User
    {
        private string _userEmail;
        public string Email
        {
            get { return _userEmail; }
        }

        private string _regNo;
        public string RegNo
        {
            get { return _regNo; }
        }

        private string _maker;
        public string Maker
        {
            get { return _maker; }
        }

        private string _model;
        public string Model
        {
            get { return _model; }
        }

        private string _color;
        public string Color
        {
            get { return _color; }
        }

        private string _cardName;
        public string CardName
        {
            get { return _cardName; }
        }

        private int _cardNo;
        public int CardNumber
        {
            get { return _cardNo; }
        }

        private DateTime _expDate;
        public DateTime ExpiryDate
        {
            get { return _expDate; }
        }

        private int _cvv;
        public int CVV
        {
            get { return _cvv; }
        }

        public Customer(string name, string password, string email) : base(name, password)
        {
            _userEmail = email;
        }

        public Customer(string name, string password, string email, string regNo, string maker, string model, string color, string cardName, int cardNo, DateTime expDate, int cvv) 
            : base(name, password)
        {
            _userEmail = email;
            _regNo = regNo;
            _maker = maker;
            _model = model;
            _color = color;
            _cardName = cardName;
            _cardNo = cardNo;
            _expDate = expDate;
            _cvv = cvv;
        }
    }
}